#ifndef _PCF8591_H_
#define _PCF8591_H_

#include "main.h"

sbit     PCF8591_SCL=P1^4;       //I2C  ʱ�� 
sbit     PCF8591_SDA=P3^2;       //I2C  ���� 


float Read_Voltage(unsigned char ch);

#endif
