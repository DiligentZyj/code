#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <Ticker.h>
#include <ArduinoJson.h>

Ticker ticker;
WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);

// WIFI或热点配置
const char *ssid     = "40pro";
const char *password = "12345678";

const char *mqttServer = "mqtt.lewei50.com";  //*MQTT连接参数你的设备登陆网址*//
String clientId = "7ca9c2a9773e4b3299973093b81cc11b_02";   //*这里的字符串要与自己的设备MQTT参数相同*//

// 乐联账号信息
String user = "test20230626";
String usr_password = "123456";

String rx_data;

// Ticker计数用变量
int count;
// 温湿度值及卷帘控制参数
int temperature = 0, humidity = 0, on_off = 0;

// put function declarations here:
void connectMQTTServer();
void connectWifi();
void tickerCount();
void pubMQTTmsg();
void subMQTTmsg();
void callback(char *topic, byte *payload, unsigned int length);

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  //设置ESP8266工作模式为无线终端模式
  WiFi.mode(WIFI_STA);  // 无线透传
  // 连接WiFi
  connectWifi();
  // 设置MQTT服务器和端口号
  mqttClient.setCallback(callback);
  mqttClient.setServer(mqttServer, 1883);
  // 连接MQTT服务器
  connectMQTTServer();
  subMQTTmsg();
  // Ticker定时对象
  ticker.attach(1, tickerCount);
}

void loop() { 
  if (mqttClient.connected()) { // 如果开发板成功连接服务器
    // 每隔15秒钟发布一次信息
    if (count == 0){
      pubMQTTmsg();
      count++;
    }
    // 保持心跳
    mqttClient.loop();
  } else {                  // 如果开发板未能成功连接服务器
    connectMQTTServer();    // 则尝试连接服务器
  }
}
 
void connectMQTTServer(){
  // 连接MQTT服务器
  if (mqttClient.connect(clientId.c_str(), user.c_str(), usr_password.c_str())) { 
    // Serial.println("MQTT Server Connected.");
    // Serial.println("Server Address: ");
    // Serial.println(mqttServer);
    // Serial.println("ClientId:");
    // Serial.println(clientId);
  } else {
    // Serial.print("MQTT Server Connect Failed. Client State:");
    // Serial.println(mqttClient.state());
    delay(100000);
  }   
}
 
// 发布信息
void pubMQTTmsg(){
  // static int value; // 客户端发布信息用数字

  String topicString = "/lw/u/7ca9c2a9773e4b3299973093b81cc11b_02";
  char publishTopic[topicString.length() + 1];  
  strcpy(publishTopic, topicString.c_str());
 
  // 发布信息
  String messageString = "[{\"Name\":\"temperature\",\"Value\":\"" + String(temperature) + "\"},{\"Name\":\"humidity\",\"Value\":\"" + String(humidity) +"\"}]"; 
  char publishMsg[messageString.length() + 1];
  strcpy(publishMsg, messageString.c_str());
  
  // 实现ESP8266向主题发布信息
  if(mqttClient.publish(publishTopic, publishMsg)){
    // Serial.println("Publish Topic:");Serial.println(publishTopic);
    // Serial.println("Publish message:");Serial.println(publishMsg);    
  } else {
    // Serial.println("Message Publish Failed."); 
  }
}

// 订阅信息
void subMQTTmsg(){
  static int value; // 客户端发布信息用数字

  String topicString = "/lw/c/7ca9c2a9773e4b3299973093b81cc11b_02";
  char publishTopic[topicString.length() + 1];  
  strcpy(publishTopic, topicString.c_str());

  mqttClient.subscribe(topicString.c_str());

  // if(mqttClient.subscribe(topicString.c_str()))  Serial.println("Sub success!");
  // else Serial.println("Sub error!");
}

void callback(char *topic, byte *payload, unsigned int length)
{
  // Serial.print("Message arrived [");
  // Serial.print(topic);
  // Serial.print("] ");
  // Serial.println();
  // Serial.println(String(length));
  String json = "";

  for (int i = 0; i < length; i++)
  {
    json += ((char)payload[i]);
  }

  // Serial.println("json:" + json);
  DynamicJsonDocument  jsonBuffer(200);
  deserializeJson(jsonBuffer, json);
  JsonObject root = jsonBuffer.as<JsonObject>();
  const char *f = root["f"];
  int p2;
  // Serial.println(f);
  
  const char *pubtopic = "/lw/r/7ca9c2a9773e4b3299973093b81cc11b_02";

  if(String(topic) == "/lw/c/" + clientId){
    if(strcmp(f, "updateSensor") == 0) {
      p2 = root["p2"];
      Serial.print(p2);
    }
    else{
      mqttClient.publish(pubtopic, "{\"successful\":true,\"message\":\"getAllSensors\",\"data\":\"testok\"}");
    }
  }
}
 
// ESP8266连接wifi
void connectWifi(){
  WiFi.begin(ssid, password);
 
  //等待WiFi连接,成功连接后输出成功信息
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    // Serial.print(".");
  }
  // Serial.println("");
  // Serial.println("WiFi Connected!");  
  // Serial.println(""); 
}

void tickerCount(){
  count++;
  if(count >= 15) count = 0;  // 15s更新一次
}

//串口中断入口
void serialEvent()
{
  rx_data = "";
  while (Serial.available()) 
  {
    rx_data += char(Serial.read()); 
    delay(2);
  }
  temperature = int(rx_data.c_str()[0]);
  humidity = int(rx_data.c_str()[1]);
  // Serial.println(temperature);
  // Serial.println(humidity);
}
